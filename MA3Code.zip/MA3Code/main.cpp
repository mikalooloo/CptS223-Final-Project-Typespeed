#include <map>
#include "TwitterData.hpp"

int main(int argc, char* argv[])
{
	// we need a map to store our key-value pairs
	// std::map<keyType, ValueType>; What should the key be? What about the value?

	
	return 0;
}