#include <map>
#include "TwitterData.hpp"
#include <sstream>
#include <algorithm>

/*
1. Used username, not only were the usernames seperate from the rest of the information, but usernames should always be unique to one person
2. O(Log(n))
3. O(log(n))
4. O(log(n))
5. O(log2(n))
6. O(log(n))
7. A map is like a red and black tree you don't have to make yourself. Unfortanutely, it also means you have little control over it's functions
8. It may not be the best structure if it's the category your looking for specifically, as you would have to begin by searching for the user, which
would mean looking through all the users to look for a specific category. A list or tree of some kind may be better that store specific users under a 
category (essentially, a structure for the category) that contains relevant users may be best.
*/

int main(int argc, char* argv[])
{
	std::string stream, firstname, lastname;
	int tweets = 0;
	std::ifstream infile;
	infile.open("TwitterAccounts.csv");
	// we need a map to store our key-value pairs
	// std::map<keyType, ValueType>; What should the key be? What about the value?
	std::map<std::string, TwitterData> twitters;
	getline(infile, stream, '\n');
	do {
		TwitterData *profile = new TwitterData;
		getline(infile, stream);
		if(stream.length() != 0 ){
		std::stringstream lineStream(stream);
		getline(lineStream, stream, ',');
		std::string const name = stream;
		profile->setUserName(name);
		getline(lineStream, stream, '"');
		getline(lineStream, lastname, ',');
		getline(lineStream, firstname, ',');
		stream = lastname + ", " + firstname;
		std::string const actualname = stream;
		profile->setActualName(actualname);
		getline(lineStream, stream, ',');
		std::string const ename = stream;
		profile->setEmail(ename);
		getline(lineStream, stream, ',');
		tweets = stoi(stream);
		int const numtweets = tweets;
		profile->setNumTweets(numtweets);
		getline(lineStream, stream, ',');
		std::remove(stream.begin(), stream.end(), '"');
		for(int i  = 0; i < stream.length(); i++){
			if(stream[i] == '\r'){
				stream[i] = '\0';
			}
		}
		std::string const category = stream;
		profile->setCategory(category);
		twitters[profile->getUserName()] = *profile;
		profile->printProfile();
		delete profile;
		}
	}
	while(!infile.eof());
	for(int i = 0; i < 3; i++){
		twitters["rangerPower"].printProfile();
		twitters["kittyKat72"].printProfile();
		twitters["lexi5"].printProfile();
		twitters["savage1"].printProfile();
		twitters["smithMan"].printProfile();
	}

	twitters.erase("savage1");
	std::cout << "Erasing element..." << std::endl;
	

	infile.close();
	return 0;
}